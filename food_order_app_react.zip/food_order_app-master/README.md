Here is live preview of this project

[Live Preview](https://tomato-order.netlify.app)

